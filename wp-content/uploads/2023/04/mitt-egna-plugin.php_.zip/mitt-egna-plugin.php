<?php
/*
Plugin Name: Mitt Plugin
Description: Lägg till en ny funktion i ditt tema
Author: Isabella

*/
?>